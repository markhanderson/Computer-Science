// Prints a row of 4 question marks

#include <stdio.h>

int main(void)
{
    printf("????\n");
}
